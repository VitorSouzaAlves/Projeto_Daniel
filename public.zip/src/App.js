import RigbyLogo from './assets/RigbyLogo.jpg'
import './App.css';

function App() {
  return (
      <header className="Logo-header">
        <p className="Texto-header">Nome irado</p>

        <div className="Rigby-logo">
          <img src={RigbyLogo} className="img-logo"/>
        </div>

      </header>
  );
}

export default App;